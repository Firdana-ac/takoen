import styled from "styled-components";

const Main = (props) => {
  return <Container>Main</Container>;
};

const Container = styled.div`
  grid-area: main;
`;

export default Main;
